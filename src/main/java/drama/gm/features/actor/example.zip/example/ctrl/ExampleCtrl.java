package ws.gm.features.actor.example.ctrl;

import ws.common.utils.mc.controler.Controler;
import ws.gm.features.actor.example.pojo.Example;

/**
 * Created by lee on 17-2-23.
 */
public interface ExampleCtrl extends Controler<Example> {
}
