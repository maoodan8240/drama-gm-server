package ws.gm.features.actor.example.ctrl;

import ws.common.utils.mc.controler.AbstractControler;
import ws.common.utils.message.interfaces.PrivateMsg;
import ws.gm.features.actor.example.pojo.Example;

/**
 * Created by lee on 17-2-23.
 */
public class _ExampleCtrl extends AbstractControler<Example> implements ExampleCtrl {
    @Override
    public void sendPrivateMsg(PrivateMsg privateMsg) {
        
    }
}
