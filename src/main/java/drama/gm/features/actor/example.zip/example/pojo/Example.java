package ws.gm.features.actor.example.pojo;

/**
 * Created by lee on 17-2-23.
 */
public class Example {
}
