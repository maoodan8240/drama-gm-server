package ws.gm.features.actor.example;

import ws.common.utils.di.GlobalInjector;
import ws.gm.features.actor.example.ctrl.ExampleCtrl;
import ws.relationship.base.actor.WsActor;

/**
 * Created by lee on 17-2-23.
 */
public class ExampleActor extends WsActor {
    private ExampleCtrl exampleCtrl;

    public ExampleActor() {
        this.enableWsActorLogger = false;
        ExampleCtrl exampleCtrl = GlobalInjector.getInstance(ExampleCtrl.class);
        this.exampleCtrl = exampleCtrl;
    }

    @Override
    public void onRecv(Object o) throws Exception {

    }
}
